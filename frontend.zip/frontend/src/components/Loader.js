import React from "react";

const Loader = () => {
  return (
    <div className="chat_wrapper">
      <div className="chat_container">
        <div className="chat_container_swing_balls">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
    </div>
  );
};

export default Loader;
