import React, { useState } from "react";


const Searchfield = () => {
  return (
   <div>
       <h2>This is a searchfield!!!</h2>
   </div>
  );
};

export default Searchfield;
