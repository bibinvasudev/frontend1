import React from "react";
import Header from "../components/Header";
import Searchquery from "../components/Searchquery";

const Body = () => {
  return (
    <>
      <div className="content_wrapper">
        <Searchquery />
      </div>
    </>
  );
};

export default Body;
