import React from 'react'

const Header = () => {
  return (
    <div className='Header'>
        <h1>
            <a href='!#'>
                <span className='logo box_content'>
                
                </span>
            </a>
        </h1>
        
    </div>
  )
}

export default Header